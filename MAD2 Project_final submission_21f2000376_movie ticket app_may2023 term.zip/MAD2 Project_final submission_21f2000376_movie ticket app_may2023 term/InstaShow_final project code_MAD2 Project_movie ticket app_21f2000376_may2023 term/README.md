steps to be taken to run this app:

Step-1: On a Linux terminal, move to the project directory.

Step-2: Start the Redis server with

$ sudo systemctl start redis

Step-3: Create the virtual environment with

$ sh requirements_inst.sh

Step-4: Start the Celery workers with

$ sh celery_activation.sh

Step-5: Run the app with

$ sh venv_activation.sh


