. venv/bin/activate
export ENV=development
python app.py
deactivate