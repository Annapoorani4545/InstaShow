import router from "./router.js";

const store = new Vuex.Store({
  state: {
    sLogin: false,
    login_error: '',
    signup_error: '',
    logout_error: '',
    user: null
  },

  getters: {
    isSLogin: (state) => state.sLogin,
    getUser: (state) => state.user,
  },

  mutations: {
    SET_LOGGED_IN(state, value) {
      state.sLogin = value;
    },
    SET_LOGIN_ERROR(state, error) {
      state.login_error = error;
    },
    SET_SIGNUP_ERROR(state, error) {
      state.signup_error = error;
    },
    SET_LOGOUT_ERROR(state, error) {
      state.logout_error = error;
    },
    SET_USER(state, user) {
      state.user = user;
    }
  },

  actions: {
    async logout({ commit }) {
      try {
        const response = await fetch('/api/logout', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          }
        });
        const data = await response.json();

        if (data.success) {
          commit('SET_LOGGED_IN', false);
          commit('SET_USER', null);
          router.push('/login');
        } else {
          commit('SET_LOGOUT_ERROR', 'Unable to logout');
        }
      } catch (error) {
        commit('SET_LOGOUT_ERROR', error);
      }
    },

    async login({ commit }, { username, password, remember }) {
      try {
        const response = await fetch('/api/login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            username: username,
            password: password,
            remember: remember
          })
        });
        const data = await response.json();

        if (data.success) {
          commit('SET_LOGGED_IN', true);
          commit('SET_USER', data.user);
          commit('SET_LOGIN_ERROR', '');
          router.push('/');
        } else {
          commit('SET_LOGIN_ERROR', data.message);
        }
      } catch (error) {
        commit('SET_LOGIN_ERROR', error);
      }
    },

    async signup({ commit }, { username, email, password }) {
      try {
        const response = await fetch('/api/signup', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            username: username,
            email: email,
            password: password
          })
        });
        const data = await response.json();

        if (data.success) {
          commit('SET_LOGGED_IN', true);
          commit('SET_USER', data.user);
          commit('SET_SIGNUP_ERROR', '');
          router.push('/');
        } else {
          commit('SET_SIGNUP_ERROR', data.message);
        }
      } catch (error) {
        commit('SET_SIGNUP_ERROR', 'An error occurred during signup');
      }
    }
  },
});

export default store;
