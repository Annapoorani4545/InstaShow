import Login from "../webpages/login.js";
import HomePage from "../webpages/Home_Page.js";
import Reserved from "../webpages/My_Bookings.js";
import Theatres from "../webpages/theatres.js";
import Shows from "../webpages/shows.js";
import Signup from "../webpages/signup.js";
import ModifyExScreens from "../webpages/Modify_ExScreens.js";
import AddMovieScreening from "../webpages/Add_MovieScreening.js";
import Messages from "../webpages/messages.js";
import AddNewShow from "../webpages/Add_NewShow.js";
import ModifyExTags from "../webpages/Modify_ExTags.js";
import CProfile from "../webpages/Company_Profile.js";
import AddNewScreen from "../webpages/Add_NewScreen.js";
import Theatre from "../webpages/theatre.js";
import AddNewTags from "../webpages/Add_NewTags.js";
import Running from "../webpages/running.js";
import ModifyExShow from "../webpages/Modify_ExShow.js";
import Show from "../webpages/show.js";
import store from "./hi.js";


const routes = [
    {
        path: "/play/:id",
        component: AddMovieScreening,
        meta: { requiresAdmin: true, requiresAuth: true },
    },
    {
        path: "/theatres",
        component: Theatres,
        meta: { requiresAuth: true },
    },
    {
        path: "/Add_NewScreen",
        component: AddNewScreen,
        meta: { requiresAdmin: true, requiresAuth: true },
    },
    {
        path: "/show/:id",
        component: Show,
        meta: { requiresAuth: true },
    },
    {
        path: "/login",
        component: Login,
    },
    {
        path: "/Modify_ExShow/:id",
        component: ModifyExShow,
        meta: { requiresAdmin: true, requiresAuth: true },
    },
    {
        path: "/signup",
        component: Signup,
    },
    {
        path: "/theatre/:id",
        component: Theatre,
        meta: { requiresAuth: true },
    },
    {
        path: "/My_Bookings",
        component: Reserved,
        meta: { requiresAuth: true },
    },
    {
        path: "/Modify_ExTags/:id",
        component: ModifyExTags,
        meta: { requiresAdmin: true, requiresAuth: true },
    },
    {
        path: "/shows",
        component: Shows,
        meta: { requiresAuth: true },
    },
    {
        path: "/Company_Profile",
        component: CProfile,
        meta: { requiresAuth: true },
    },
    {
        path: "/running/:id",
        component: Running,
        meta: { requiresAuth: true },
    },
    {
        path: "/Modify_ExScreens/:id",
        component: ModifyExScreens,
        meta: { requiresAdmin: true, requiresAuth: true },
    },
    {
        path: "/Add_NewTags",
        component: AddNewTags,
        meta: { requiresAdmin: true, requiresAuth: true },
    },
    {
        path: "/messages",
        component: Messages,
        meta: { requiresAuth: true },
    },
    {
        path: "/",
        component: HomePage,
        meta: { requiresAuth: true },
    },
    {
        path: "/Add_NewShow",
        component: AddNewShow,
        meta: { requiresAdmin: true, requiresAuth: true },
    },
];

const router = new VueRouter({
    routes,
});

router.beforeEach((to, from, next) => {
    const isSLogin = store.getters.isSLogin;

    if (to.meta.requiresAuth && !isSLogin) {
        next('/login');
    } else if ((to.path === '/login' || to.path === '/signup') && isSLogin) {
        next('/');
    } else {
        next();
    }

    if (isSLogin) {
        const auth = store.getters.getUser.auth;

        if (to.meta.requiresAdmin && auth !== 2) {
            next('/');
        } else {
            next();
        }
    }
});

export default router;
