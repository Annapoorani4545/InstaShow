import router from './router.js';
import store from './hi.js';

const app = new Vue({
  el: '#app',
  delimiters: ['${', '}'],
  router,
  store,
  data: {},

  methods: {
    handleLogout() {
      this.$store.dispatch('logout');
    },
  },

  created() {
    fetch('/api/check_slogin')
      .then((response) => response.json())
      .then((data) => {
        if (data.isSLogin) {
          this.$store.commit('SET_LOGGED_IN', true);
          this.$store.commit('SET_USER', data.user);
          router.push('/');
        } else {
          this.$store.commit('SET_LOGGED_IN', false);
          this.$store.commit('SET_USER', null);
        }
      })
      .catch((error) => {
        this.$store.commit('SET_LOGIN_ERROR', error);
      });
  },
});
