const Signup = Vue.component("signup", {
  template: `
    <div class="row">
      <div class="col-lg-4"></div>
      <div class="form-wrapper col-lg-4">
        <label class="error" v-if="error" style="color: red;">{{ error }}</label>
        <h2 class="title">Create New Account:</h2>
        <form class="form" @submit.prevent="handleSubmit">
          <div class="form-group">
            <label for="username" class="form-label">Enter a Username:</label>
            <div class="input-box">
              <input type="text" id="username" v-model="username" required class="form-control"/>
            </div>
          </div>

          <div class="form-group">
            <label for="email" class="form-label">Enter valid Email ID:</label>
            <div class="input-box">
              <input type="email" id="email" v-model="email" required class="form-control"/>
            </div>
          </div>

          <div class="form-group">
            <label for="password" class="form-label">Enter a Password:</label>
            <div class="input-box">
              <input id="password" v-model="password" :type="type" required class="form-control" style="width: 100%;"/>
            </div>
          </div>

          <div class="form-group">
            <div class="input-box">
              <input type="checkbox" id="show" v-model="text" class="form-check-input"/>
              <label>Show Password</label>
            </div>
          </div>

          <div class="form-group" v-if="strength < 100 && password.length > 0">
            Password Strength : {{ strength }}%
            <br>
            <label class="error" style="color: red;">At least 1 lowercase character, 1 uppercase character, 1 digit, 1 special character, 6 characters</label>
          </div>

          <div class="form-group">
            <label for="repeatPassword" class="form-label">Confirm Password:</label>
            <div class="input-box">
              <input type="password" id="repeatPassword" v-model="repeatPassword" @input="repeatPasswordValidation" required class="form-control" style="width: 100%;"/>
            </div>
          </div>

          <div class="form-group">
            <label class="error" v-if="invalid && repeatPassword.length > 0" style="color: red;">Passwords must match</label>
          </div>

          <div class="form-group" style="margin-top: 20px;">
            <button class="btn btn-info btn-lg submit" v-if="valid" type="submit">Create Account</button>
          </div>
        </form>
        <div class="login-button" style="margin-top: 20px;">
          <router-link to="/login" class="btn btn-primary" style="margin-top: 10px;">Login</router-link>
        </div>
      </div>
      <div class="col-lg-4"></div>
    </div>
  `,

  data() {
    return {
      username: '',
      email: '',
      password: '',
      repeatPassword: '',
      invalid: true,
      error: '',
      text: false,
      type: 'password',
      weak: {
        lowercase: true,
        uppercase: true,
        digit: true,
        special: true,
        length: true,
      },
      strength: 0
    }
  },

  computed: {
    valid() {
      if (this.invalid == false && this.strength == 100) {
        return true
      } else {
        return false
      }
    }
  },

  methods: {
    handleSubmit() {
      // Dispatch the signup action from the Vuex store
      this.$store.dispatch('signup', {
        username: this.username,
        email: this.email,
        password: this.password
      });
    },

    repeatPasswordValidation() {
      if (this.repeatPassword != this.password) {
        this.invalid = true
      } else {
        this.invalid = false
      }
    },

    calc_strength() {
      let c = 0;
      for (const i in this.weak) {
        if (this.weak[i] == false) {
          c += 1;
        }
      }
      this.strength = c / 5 * 100;
    }
  },

  watch: {
    text(boolean) {
      this.type = 'password';
      if (boolean) {
        this.type = 'text'
      } else {
        this.type = 'password'
      }
    },

    password(new_value) {
      this.weak.lowercase = true;
      this.weak.uppercase = true;
      this.weak.digit = true;
      this.weak.special = true;
      this.weak.length = true;

      if (new_value.length > 7) {
        this.weak.length = false;
      }

      for (let i = 0; i < new_value.length; i++) {
        let a = new_value[i];
        let b = new_value.charCodeAt(i);

        if (a >= "a" && a <= "z") {
          this.weak.lowercase = false;
        }
        else if (a >= "A" && a <= "Z") {
          this.weak.uppercase = false;
        }
        else if (a >= "0" && a <= "9") {
          this.weak.digit = false;
        }
        else if ((b >= 32 && b <= 47) || (b >= 58 && b <= 64)) {
          this.weak.special = false;
        }
      }
      this.calc_strength();
    },

    '$store.state.signup_error'(value) {
      this.error = value;
    }
  }
})

export default Signup;

