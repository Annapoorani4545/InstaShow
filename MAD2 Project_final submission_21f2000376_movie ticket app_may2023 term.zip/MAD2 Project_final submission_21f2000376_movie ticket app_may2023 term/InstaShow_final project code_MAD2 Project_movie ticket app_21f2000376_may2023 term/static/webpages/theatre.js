import router from "../js/router.js";

const Theatre = Vue.component("theatre", {
  template: `
    <div>
      <h1>Screen</h1>
      <label :style="{ color: 'red' }" v-if="error">{{ error }}</label>
      <div v-if="theatre" class="row" style="margin-bottom: 60px;">
        <div class="col-lg-6">
          <h4>{{ theatre.name }}</h4>
          <p style="text-align: center">Theatre Address: {{ theatre.location }}</p>
          <p style="text-align: center">Theatre Capacity: {{ theatre.seating }}</p>
          <p style="text-align: center">Revenue Generated: {{ theatre.income }}</p>

          <div style="margin-top: 20px;">
            <router-link :to="'/Modify_ExScreens/' + theatre.id">
              <button :style="{ backgroundColor: 'orange' }" v-if="$store.getters.getUser.auth === 2">Edit Theatre</button>
            </router-link>
            <form v-if="$store.getters.getUser.auth === 2" @submit.prevent="rmo">
              <button :style="{ backgroundColor: 'red' }" type="submit" @click="confirmDelete">Delete Theatre</button>
            </form>
            <button :style="{ backgroundColor: 'blue' }" @click="download">
              <i class="fa fa-download"></i> Download Details
            </button>
          </div>
        </div>
        <div class="col-lg-6">
          <h3>Currently Available Shows:</h3>
          <h3 v-if="theatre.shows.length === 0">No shows available currently!</h3>
          <table class="table table-bordered table-hover">
            <thead>
              <tr>
                <th>Movie Screening</th>
                <th>Show Timings</th>
                <th v-if="$store.getters.getUser.auth === 2">Cancel Show</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="show in theatre.shows">
                <td>
                  <router-link :to="'/running/' + show.id">{{ show.name }}</router-link>
                </td>
                <td>{{ show.start_time }} - {{ show.end_time }}</td>
                <td v-if="$store.getters.getUser.auth === 2">
                  <button :style="{ backgroundColor: 'red' }" @click="r_sc(show.id)">Cancel Show</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,

  data() {
    return {
      theatre: null,
      error: ''
    };
  },

  methods: {
    async fetchTheatre() {
      const id = this.$route.params.id;
      try {
        const response = await fetch(`/api/theatre/${id}`);
        const data = await response.json();

        if (data.success) {
          this.theatre = data.theatre;
          this.error = '';
        } else {
          this.theatre = null;
          this.error = data.message;
          router.push('/theatres');
        }
      } catch (error) {
        this.error = error;
      }
    },

    async rmo() {
      const id = this.$route.params.id;
      try {
        const response = await fetch(`/api/theatre/${id}`, {
          method: 'DELETE'
        });
        const data = await response.json();

        if (data.success) {
          this.error = '';
          router.push('/theatres');
        } else {
          this.error = data.message;
          if (data.message === 'Theatre does not exist') {
            router.push('/theatres');
          }
        }
      } catch (error) {
        this.error = error;
      }
    },

    async r_sc(id) {
      try {
        const response = await fetch(`/api/running/${id}`, {
          method: 'DELETE'
        });
        const data = await response.json();

        if (data.success) {
          this.error = '';
          this.fetchTheatre();
        } else {
          this.error = data.message;
          if (data.message !== 'Show is currently running') {
            router.push('/');
          }
        }
      } catch (error) {
        this.error = error;
      }
    },

    async download() {
      const id = this.$route.params.id;
      try {
        const response = await fetch(`/api/download_ttd/${id}`);
        const blob = await response.blob();
        const filename = `theatre_${id}.docx`;
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } catch (error) {
        this.error = error;
      }
    },

    confirmDelete() {
      if (confirm('Please Confirm whether you want to delete this theatre?')) {
        this.rmo();
      }
    }
  },

  mounted() {
    this.fetchTheatre();
  }
});

export default Theatre;

