const Reserved = Vue.component("My_Bookings", {
  template: `
    <div style="background-color: lightpink; padding: 20px;">
      <h2 style="font-size: 24px; margin-bottom: 20px;">My Show Bookings:</h2>
      <label class="error" v-if="error" style="color: red; font-size: 16px;">{{ error }}</label>
      <h3 v-if="message" style="font-size: 18px;">No Show bookings made yet.</h3>
      <table class="table table-bordered table-hover" style="width: 100%; border-collapse: collapse;">
        <thead>
          <tr>
            <th style="font-weight: bold;">Movie Screening show</th>
            <th style="font-weight: bold;">Theatre Name</th>
            <th style="font-weight: bold;">Number of Tickets</th>
            <th style="font-weight: bold;">Show Timings</th>
            <th style="font-weight: bold;">Cancel Booking</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="booking in bookings" style="border-top: 1px solid #ccc;">
            <td><router-link :to="'/running/' + booking.running_id" style="text-decoration: underline; color: blue;">{{ booking.show_name }}</router-link></td>
            <td>{{ booking.theatre_name }}</td>
            <td>{{ booking.tickets }}</td>
            <td>{{ booking.start_time }} - {{ booking.end_time }}</td>
            <td><button class="btn btn-danger btn-sm" @click="rmmb(booking.id)" style="background-color: red; color: white; border: none; padding: 5px 10px; cursor: pointer;">Cancel</button></td>
          </tr>
        </tbody>
      </table>
    </div>
  `,

  data() {
    return {
      bookings: [],
      error: '',
      message: ''
    }
  },

  methods: {
    async fetchShows() {
      try {
        const id = this.$store.getters.getUser.id;
        const response = await fetch(`/api/My_Bookings/${id}`, {
          method: 'GET'
        });
        const data = await response.json();
        if (data.success) {
          this.bookings = data.bookings;
          this.message = '';
          this.error = '';
        } else {
          this.message = data.message;
          this.error = '';
        }
      } catch (error) {
        this.error = error;
        this.message = '';
      }
    },

    async rmmb(id) {
      try {
        const response = await fetch(`/api/rmmb/${id}`, {
          method: 'DELETE'
        });
        const data = await response.json();
        if (data.success) {
          this.bookings = this.bookings.filter(booking => booking.id != id);
          this.error = '';
        } else {
          this.error = data.message;
        }
      } catch (error) {
        this.error = error;
      }
    }
  },

  mounted() {
    this.fetchShows();
  }
});

export default Reserved;

