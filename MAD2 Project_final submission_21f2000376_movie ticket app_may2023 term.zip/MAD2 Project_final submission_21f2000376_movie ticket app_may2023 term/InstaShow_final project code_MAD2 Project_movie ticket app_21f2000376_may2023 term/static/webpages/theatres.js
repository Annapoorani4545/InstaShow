const Theatres = Vue.component("theatres", {
  template: `
    <div style="margin: 20px auto; text-align: center;">
      <h1 style="margin-bottom: 20px;">Screens</h1>
      <div class="row justify-content-center">
        <div class="col-lg-4" style="text-align: center;">
          <button class="btn btn-primary btn-lg" @click="download">
            <i class="fa fa-download"></i> Download CSV
          </button>
        </div>
        <div class="col-lg-4" style="text-align: center;">
          Search Theatre by Name &nbsp;&nbsp;&nbsp;
          <form @submit.prevent="find_screen">
            <input type="text" v-model="search" name="search" class="default">
            <button type="submit" class="btn btn-info">
              <i class="fa fa-search"></i>
            </button>
          </form>
        </div>
        <div class="col-lg-4" style="text-align: center;">
          Search Theatre by Place/Address &nbsp;&nbsp;&nbsp;
          <form @submit.prevent="adscr">
            <input type="text" v-model="searchLocation" name="searchLocation" class="default">
            <button type="submit" class="btn btn-info">
              <i class="fa fa-search"></i>
            </button>
          </form>
        </div>
      </div>
      <label class="error" v-if="error" style="color: red;">{{ error }}</label>
      <h3 v-if="message" style="color: green;">{{ message }}</h3>
      <table class="table table-bordered table-hover" style="margin-top: 20px;">
        <thead>
          <tr>
            <th>Theatre Screen</th>
            <th>Theatre Address</th>
            <th>Theatre Capacity</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="theatre in theatres">
            <td>
              <router-link :to="'/theatre/' + theatre.id">{{ theatre.name }}</router-link>
            </td>
            <td>{{ theatre.location }}</td>
            <td>{{ theatre.seating }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  `,

  data() {
    return {
      theatres: [],
      search: '',
      searchLocation: '',
      error: '',
      message: ''
    };
  },

  methods: {
    async fetchTheatres() {
      try {
        const response = await fetch('/api/theatres', {
          method: 'GET'
        });
        const data = await response.json();

        if (data.success) {
          this.theatres = data.theatres;
          this.message = '';
          this.error = '';
        } else {
          this.message = data.message;
          this.error = '';
        }
      } catch (error) {
        this.error = error;
        this.message = '';
      }
    },

    async find_screen() {
      try {
        const response = await fetch('/api/find_screen', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            search: this.search
          })
        });
        const data = await response.json();

        if (data.success) {
          this.theatres = data.theatres;
          this.message = '';
          this.error = '';
        } else {
          this.message = data.message;
          this.error = '';
        }
      } catch (error) {
        this.error = error;
        this.message = '';
      }
    },

    async adscr() {
      try {
        const response = await fetch('/api/adscr', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            search: this.searchLocation
          })
        });
        const data = await response.json();

        if (data.success) {
          this.theatres = data.theatres;
          this.message = '';
          this.error = '';
        } else {
          this.message = data.message;
          this.error = '';
        }
      } catch (error) {
        this.error = error;
        this.message = '';
      }
    },

    async download() {
      try {
        const response = await fetch(`/api/download_screensinfo`);
        const blob = await response.blob();
        const filename = 'screen_data.csv';
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } catch (error) {
        this.error = error;
      }
    }
  },

  mounted() {
    this.fetchTheatres();
  }
});

export default Theatres;

