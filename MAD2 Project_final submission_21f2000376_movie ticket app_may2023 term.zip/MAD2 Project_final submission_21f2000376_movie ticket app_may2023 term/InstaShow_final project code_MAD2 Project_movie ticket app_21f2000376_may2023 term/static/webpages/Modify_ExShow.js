import router from "../js/router.js";

const ModifyExShow = Vue.component("Modify_ExShow", {
  template: `
    <div class="row">
      <div class="col-lg-4"></div>
      <div class="form-wrapper col-lg-4">
        <h2 class="title" style="text-align: center; margin-bottom: 20px;">Modify Existing Shows:</h2>
        <form class="form" @submit.prevent="Modify_ExShow">
          <div class="form-group">
            <label for="name" class="form-label" style="font-weight: bold;">New Show Name:</label>
            <input type="text" id="name" v-model="name" required class="form-control" style="width: 100%;"/>
          </div>
          <div class="form-group">
            <label for="rating" class="form-label" style="font-weight: bold;">New Show Rating:</label>
            <input type="text" id="rating" v-model="rating" required class="form-control" style="width: 100%;"/>
          </div>
          <div class="form-group">
            <label for="tags" class="form-label" style="font-weight: bold;">New Tags:</label>
            <select id="tags" name="tags" multiple v-model="selected_tags" class="form-select" style="width: 100%;">
              <option v-for="tag in tags" :value="tag.id">{{ tag.name }}</option>
            </select>
          </div>
          <div class="form-group" style="text-align: center;">
            <button class="btn btn-warning btn-lg submit" type="submit" style="width: 50%;">Save Changes</button>
          </div>
        </form>
        <div class="error" v-if="error" style="color: red; text-align: center; margin-top: 10px;">{{ error }}</div>
      </div>
      <div class="col-lg-4"></div>
    </div>
  `,

  data() {
    return {
      name: "",
      rating: "",
      tags: [],
      selected_tags: [],
      error: ""
    };
  },

  methods: {
    async fetchShow() {
      const id = this.$route.params.id;
      try {
        const response = await fetch(`/api/show/${id}`);
        const data = await response.json();
        if (data.success) {
          this.name = data.show.name;
          this.rating = data.show.rating;
          this.selected_tags = data.show.tags;
          this.error = "";
        } else {
          this.name = "";
          this.rating = "";
          this.selected_tags = [];
          this.error = data.message;
          router.push("/shows");
        }
      } catch (error) {
        this.error = error;
      }
    },

    async fetchTags() {
      try {
        const response = await fetch("/api/tags");
        const data = await response.json();
        if (data.success) {
          this.tags = data.tags;
          this.error = "";
        }
      } catch (error) {
        this.error = error;
      }
    },

    Modify_ExShow() {
      const id = this.$route.params.id;
      fetch(`/api/show/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          name: this.name,
          rating: this.rating,
          tags: this.selected_tags
        })
      })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            this.error = "";
            const id = data.id;
            router.push(`/show/${id}`);
          } else {
            this.error = data.message;
            if (data.message === "Show does not exist") {
              router.push("/shows");
            }
          }
        })
        .catch(error => {
          this.error = error;
        });
    }
  },

  mounted() {
    this.fetchTags();
    this.fetchShow();
  }
});

export default ModifyExShow;

