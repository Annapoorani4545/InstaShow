import router from "../js/router.js";

const Running = Vue.component("running", {
  template: `
    <div style="background-color: #FFD700;">
      <h1 style="text-align: center;">Show selected:</h1>
      <label v-if="error" style="color: red; text-align: center;">{{ error }}</label>
      <div v-if="running">
        <h3>Show Name: {{ running.show_name }}</h3>
        <h3>Theatre Name: {{ running.theatre_name }}</h3>
        <p style="text-align: center;">Movie Rating: {{ running.rating }}</p>
        <p style="text-align: center;">Ticket Price per Seat: {{ running.ticket_price }}</p>
        <p style="text-align: center;">Show Timings: {{ running.start_time }} to {{ running.end_time }}</p>
        <div class="row">
          <div class="col-lg-4"></div>
          <div class="form-wrapper col-lg-4">
            <form class="form" @submit.prevent="vaangu">
              <div class="form-group">
                <label for="tickets" class="form-label">Number of tickets:</label>
                <div class="input-group">
                  <input type="number" id="tickets" v-model="tickets" required class="form-control"/>
                  <button class="btn btn-primary btn-lg submit" type="submit">Reserve tickets now</button>
                </div>
              </div>
            </form>
          </div>
          <div class="col-lg-4"></div>
        </div>
      </div>
    </div>
  `,

  data() {
    return {
      running: null,
      tickets: null,
      error: ''
    };
  },

  methods: {
    async fetchRunning() {
      const id = this.$route.params.id;
      try {
        const response = await fetch(`/api/running/${id}`);
        const data = await response.json();
        if (data.success) {
          this.running = data.running;
          this.error = '';
        } else {
          this.running = null;
          this.error = data.message;
          router.push('/');
        }
      } catch (error) {
        this.error = error;
      }
    },

    async vaangu() {
      const user_id = this.$store.getters.getUser.id;
      const running_id = this.$route.params.id;
      try {
        const response = await fetch(`/api/vaangu/${user_id}/${running_id}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            tickets: this.tickets
          })
        });
        const data = await response.json();
        if (data.success) {
          this.error = '';
          router.push('/My_Bookings');
        } else {
          this.error = data.message;
          if (data.message === 'screen or movie show does not exist, please check again') {
            router.push('/');
          }
        }
      } catch (error) {
        this.error = error;
      }
    }
  },

  mounted() {
    this.fetchRunning();
  }
});

export default Running;

