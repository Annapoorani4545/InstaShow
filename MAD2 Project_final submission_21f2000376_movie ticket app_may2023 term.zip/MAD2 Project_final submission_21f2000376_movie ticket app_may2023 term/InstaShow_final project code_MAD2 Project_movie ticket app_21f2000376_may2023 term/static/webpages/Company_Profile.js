const CProfile = Vue.component("Company_Profile", {
    template: `
        <div>
            <h2 style="text-align: center;"> About InstaShow</h2>
            <p style="text-align: center;">InstaShow is a Movie Ticket Booking App for Theatres spread across India and Movies of more than 100+ languages</p><br>
            <p style="text-align: center;">The App is made using Vue framework of Javascript, Flask Python for Backend and HTML, css for styling.</p><br>
            <p style="text-align: center;">Founded in 2023, our mission is to make the process of discovering and booking movie tickets seamless, convenient, and enjoyable for moviegoers across India.</p>
            <br>
            <p style="text-align: center;">We are dedicated to providing a platform that caters to the diverse needs and preferences of our users while fostering a deeper connection between movie enthusiasts and the cinematic world.</p>
            <p style="text-align: center; font-weight: bold; color: #FF5733;">Discounted ticket prices exclusively in InstaShow!! So cinephiles, what are you waiting for... </p>

            <div style="position: absolute; bottom: 60px; left: 10px;">
                <p>(Current) Username: {{ user.username }}</p>
                <p>(Current) Email: {{ user.email }}</p>
            </div>
        </div>
    `,

    data() {
        return {
            user: {},
            error: ''
        }
    },

    methods: {
        fetchUser() {
            fetch('/api/user', {
                method: 'GET'
            })
            .then(response => response.json())
            .then(data => {
                this.user = data.user;
            })
            .catch(error => {
                this.error = error;
            })
        }
    },

    mounted() {
        this.fetchUser();
    }
});

export default CProfile;
