import router from "../js/router.js";

const ModifyExTags = Vue.component("Modify_ExTags", {
  template: `
    <div class="page" style="background-color: lightgreen;">
      <div class="row">
        <div class="col-lg-4"></div>
        <div class="form-wrapper col-lg-4">
          <label class="error" v-if="error" style="color: red; margin-bottom: 10px;">{{ error }}</label>
          <h2 class="title" style="font-size: 24px; margin-bottom: 10px;">Modify Existing Tags:</h2>
          <form class="form" @submit.prevent="Modify_ExTags">
            <div class="form-group" style="display: flex; flex-direction: row; align-items: center; justify-content: space-between; margin-bottom: 10px;">
              <label for="name" class="form-label" style="flex: 1; margin-right: 10px; text-align: right;">New Tag Name:</label>
              <input type="text" id="name" v-model="name" required class="form-control" style="flex: 2;" />
            </div>
            <button class="btn btn-warning btn-lg submit" type="submit" style="background-color: #FFA500; color: white;">Save Changes</button>
          </form>
        </div>
        <div class="col-lg-4"></div>
      </div>
    </div>
  `,

  data() {
    return {
      name: "",
      error: "",
    };
  },

  methods: {
    async fetchTag() {
      const id = this.$route.params.id;
      try {
        const response = await fetch(`/api/tag/${id}`);
        const data = await response.json();
        if (data.success) {
          this.name = data.tag.name;
          this.error = "";
        } else {
          this.name = "";
          this.error = data.message;
          router.push("/Add_NewTags");
        }
      } catch (error) {
        this.error = error;
      }
    },

    async Modify_ExTags() {
      const id = this.$route.params.id;
      try {
        const response = await fetch(`/api/tag/${id}`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            name: this.name,
          }),
        });
        const data = await response.json();
        if (data.success) {
          this.error = "";
          router.push("/Add_NewTags");
        } else {
          this.error = data.message;
          router.push("/Add_NewTags");
        }
      } catch (error) {
        this.error = error;
      }
    },
  },

  mounted() {
    this.fetchTag();
  },
});

export default ModifyExTags;

