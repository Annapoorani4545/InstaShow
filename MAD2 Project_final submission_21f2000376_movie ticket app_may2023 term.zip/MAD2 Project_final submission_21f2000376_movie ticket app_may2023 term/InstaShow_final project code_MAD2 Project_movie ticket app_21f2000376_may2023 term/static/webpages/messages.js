const Messages = Vue.component("messages", {
  template: `
    <div style="background-color: lightbrown;">
      <label v-if="error" style="color: red;">{{ error }}</label>
      <h2 v-if="message" style="font-size: 1.5em;">{{ message }}</h2>
      <table class="table table-bordered table-hover" style="width: 100%;">
        <thead>
          <tr>
            <th style="border: 1px solid #ccc; padding: 8px;">Date/Time</th>
            <th style="border: 1px solid #ccc; padding: 8px;">Notification</th>
            <th style="border: 1px solid #ccc; padding: 8px;">Delete</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="message in messages" style="border: 1px solid #ccc;">
            <td style="border: 1px solid #ccc; padding: 8px;">{{ message.time }}</td>
            <td style="border: 1px solid #ccc; padding: 8px;">{{ message.notifi }}</td>
            <td style="border: 1px solid #ccc;"><button style="background-color: red; color: white; border: none; padding: 5px 10px; cursor: pointer;" @click="delete_message(message.id)">Delete</button></td>
          </tr>
        </tbody>
      </table>
    </div>
  `,

  data() {
    return {
      messages: [],
      message: '',
      error: ''
    };
  },

  methods: {
    async fetchMessages() {
      const id = this.$store.getters.getUser.id;
      try {
        const response = await fetch(`/api/messages/${id}`);
        const data = await response.json();
        if (data.success) {
          this.messages = data.messages;
          this.message = '';
          this.error = '';
        } else {
          this.message = data.message;
          this.error = '';
        }
      } catch (error) {
        this.error = error;
        this.message = '';
      }
    },

    async delete_message(id) {
      try {
        const response = await fetch(`/api/messages/${id}`, {
          method: 'DELETE'
        });
        const data = await response.json();
        if (data.success) {
          this.messages = this.messages.filter(message => message.id !== id);
          this.message = '';
          this.error = '';
        } else {
          this.error = data.error;
        }
      } catch (error) {
        this.error = error;
      }
    }
  },

  mounted() {
    this.fetchMessages();
  }
});

export default Messages;
