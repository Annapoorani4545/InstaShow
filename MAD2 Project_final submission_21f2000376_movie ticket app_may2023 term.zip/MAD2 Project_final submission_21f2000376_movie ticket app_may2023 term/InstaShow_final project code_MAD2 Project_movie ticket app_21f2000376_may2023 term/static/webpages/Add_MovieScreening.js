import router from "../js/router.js";

const AddMovieScreening = Vue.component("Add_MovieScreening", {
  template: `
    <div class="row" style="background-color: #f5deb3;">
      <div class="col-lg-4"></div>
      <div class="form-wrapper col-lg-4" style="padding: 20px; border: 1px solid #ccc; border-radius: 5px;">
        <label class="error" v-if="error" style="color: red;">{{ error }}</label>
        <h2 class="title" style="font-size: 24px;">Add Movie Screening:</h2>
        <form class="form" @submit.prevent="Add_MovieScreening">
          <div class="form-group">
            <label for="theatre" class="form-label" style="font-weight: bold;">Theatre Name:</label>
            <select id="theatre" name="theatre" v-model="selectedTheatre" class="form-select">
              <option v-for="theatre in theatres" :value="theatre.id">{{ theatre.name }}</option>
            </select>
          </div>
          <div class="form-group">
            <label for="date" class="form-label" style="font-weight: bold;">Screening Date:</label>
            <input type="date" id="date" name="date" v-model="date" required class="form-control"/>
          </div>
          <div class="form-group">
            <label for="start_time" class="form-label" style="font-weight: bold;">Show Start Time:</label>
            <input type="time" id="start_time" name="start_time" v-model="startTime" required class="form-control"/>
          </div>
          <div class="form-group">
            <label for="end_time" class="form-label" style="font-weight: bold;">Show End Time:</label>
            <input type="time" id="end_time" name="end_time" v-model="endTime" required class="form-control"/>
          </div>
          <button class="btn btn-primary btn-lg submit" type="submit" style="margin-top: 10px;">Add Screening</button>
        </form>
      </div>
      <div class="col-lg-4"></div>
    </div>
  `,

  data() {
    return {
      theatres: [],
      selectedTheatre: null,
      date: null,
      startTime: null,
      endTime: null,
      error: '',
    };
  },

  methods: {
    async fetchTheatres() {
      try {
        const response = await fetch('/api/theatres');
        const data = await response.json();
        if (data.success) {
          this.theatres = data.theatres;
          this.error = '';
        }
      } catch (error) {
        this.error = error;
      }
    },

    async Add_MovieScreening() {
      const id = this.$route.params.id;
      try {
        const response = await fetch(`/api/Add_MovieScreening/${id}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            theatre_id: this.selectedTheatre,
            date: this.date,
            start_time: this.startTime,
            end_time: this.endTime,
          }),
        });
        const data = await response.json();
        if (data.success) {
          this.error = '';
          const showId = data.id;
          router.push(`/show/${showId}`);
        } else {
          this.error = data.message;
          router.push('/shows');
        }
      } catch (error) {
        this.error = error;
      }
    },
  },

  mounted() {
    this.fetchTheatres();
  },
});

export default AddMovieScreening;

