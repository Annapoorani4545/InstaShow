import router from "../js/router.js";

const AddNewScreen = Vue.component("Add_NewScreen", {
  template: `
    <div style="display: flex; justify-content: center;" style="background-color: #f5deb3;">
      <div style="flex: 1;"></div>
      <div style="flex: 4;">
        <label style="color: red;" v-if="error">{{ error }}</label>
        <h2 style="font-size: 24px;">Adding New Screens:</h2>
        <form class="form" @submit.prevent="Add_NewScreen">
          <div class="form-group">
            <label for="name" style="font-weight: bold;">Theatre Name (& Screen Number):</label>
            <input type="text" id="name" v-model="name" required style="width: 100%;" class="form-control" />
          </div>
          <div class="form-group">
            <label for="location" style="font-weight: bold;">Theatre Address:</label>
            <input type="text" id="location" v-model="location" required style="width: 100%;" class="form-control" />
          </div>
          <div class="form-group">
            <label for="seating" style="font-weight: bold;">Theatre Capacity:</label>
            <input type="number" id="seating" v-model="seating" required style="width: 100%;" class="form-control" />
          </div>
          <button style="background-color: #007bff; color: white; font-size: 18px; padding: 10px;" type="submit">Add Screen</button>
        </form>
      </div>
      <div style="flex: 1;"></div>
    </div>
  `,

  data() {
    return {
      name: '',
      location: '',
      seating: null,
      error: ''
    };
  },

  methods: {
    Add_NewScreen() {
      fetch('/api/theatres', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          name: this.name,
          location: this.location,
          seating: this.seating
        })
      })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            this.error = '';
            const id = data.id;
            router.push(`/theatre/${id}`);
          } else {
            this.error = data.message;
          }
        })
        .catch(error => {
          this.error = error;
        });
    }
  }
});

export default AddNewScreen;

