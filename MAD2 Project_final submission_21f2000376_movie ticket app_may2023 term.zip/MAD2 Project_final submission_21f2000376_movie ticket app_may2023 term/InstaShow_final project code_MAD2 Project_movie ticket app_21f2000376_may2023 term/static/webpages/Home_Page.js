const HomePage = Vue.component("Home_Page", {
  template: `
    <div :style="{ 'background-color': 'lightblue' }">
      <label :style="{ 'display': error ? 'block' : 'none' }">{{ error }}</label>
      <h3 :style="{ 'font-family': 'Times New Roman', 'font-style': 'italic', 'font-weight': 'bold' }">Hello Cinephile!! Welcome!!</h3>
      <h2>Shows Currently Running:</h2>
      <h4 :style="{ 'display': running_message ? 'block' : 'none' }">{{ running_message }}</h4>
      <table class="table table-hover">
        <thead>
          <tr>
            <th>Movie Screening</th>
            <th>Movie Rating</th>
            <th>Ticket Price per Seat</th>
            <th>Show Timings</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="running in running_data">
            <td><router-link :to="'/running/' + running.id">{{ running.show_name }}</router-link></td>
            <td>{{ running.rating }}</td>
            <td>Rs {{ running.ticket_price }}</td>
            <td>{{ running.start_time }} - {{ running.end_time }}</td>
          </tr>
        </tbody>
      </table>
      <!-- Add spacing below the Currently Playing Shows table -->
      <div :style="{ 'margin-bottom': '60px' }"></div>
      <h2>Upcoming Movie Shows:</h2>
      <h4 :style="{ 'display': later_message ? 'block' : 'none' }">{{ later_message }}</h4>
      <table class="table table-hover">
        <thead>
          <tr>
            <th>Movie Screening</th>
            <th>Movie Rating</th>
            <th>Ticket Price per Seat</th>
            <th>Show Timings</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="later in later_data">
            <td><router-link :to="'/running/' + later.id">{{ later.show_name }}</router-link></td>
            <td>{{ later.rating }}</td>
            <td>Rs {{ later.ticket_price }}</td>
            <td>{{ later.start_time }} - {{ later.end_time }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  `,

  data() {
    return {
      running_data: [],
      later_data: [],
      error: '',
      running_message: '',
      later_message: ''
    };
  },

  methods: {
    async fetchRunning() {
      try {
        const response = await fetch('/api/scr_now');
        const data = await response.json();

        if (data.success) {
          this.running_data = data.data;
          this.running_message = '';
          this.error = '';
        } else {
          this.running_message = data.message;
          this.error = '';
        }
      } catch (error) {
        this.error = error;
        this.running_message = '';
      }
    },

    async fetchLater() {
      try {
        const response = await fetch('/api/varapora');
        const data = await response.json();

        if (data.success) {
          this.later_data = data.data;
          this.later_message = '';
          this.error = '';
        } else {
          this.later_message = data.message;
          this.error = '';
        }
      } catch (error) {
        this.error = error;
        this.later_message = '';
      }
    }
  },

  mounted() {
    this.fetchRunning();
    this.fetchLater();
  }
});

export default HomePage;

