import router from "../js/router.js";

const ModifyExScreens = Vue.component("Modify_ExScreens", {
  template: `
    <div class="row" style="background-color: yellow;">
      <div class="col-lg-4"></div>
      <div class="form-wrapper col-lg-4">
        <label class="error" v-if="error" style="color: red;">{{ error }}</label>
        <h2 class="title" style="font-size: 24px;">Modify Existing Screens:</h2>
        <form class="form" @submit.prevent="Modify_ExScreens">
          <div class="form-group">
            <label for="name" class="form-label">New Theatre Screen Name:</label>
            <input type="text" id="name" v-model="name" required class="form-control" style="width: 100%; padding: 5px; border: 1px solid #ccc; border-radius: 4px;">
          </div>
          <div class="form-group">
            <button class="btn btn-warning btn-lg submit" type="submit" style="background-color: #ffc107; color: #333;">Save Changes</button>
          </div>
        </form>
      </div>
      <div class="col-lg-4"></div>
    </div>
  `,

  data() {
    return {
      name: '',
      error: ''
    };
  },

  methods: {
    async fetchTheatre() {
      const id = this.$route.params.id;
      try {
        const response = await fetch(`/api/theatre/${id}`);
        const data = await response.json();
        if (data.success) {
          this.name = data.theatre.name;
          this.error = '';
        } else {
          this.name = '';
          this.error = data.message;
          router.push('/theatres');
        }
      } catch (error) {
        this.error = error;
      }
    },

    async Modify_ExScreens() {
      const id = this.$route.params.id;
      try {
        const response = await fetch(`/api/theatre/${id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            name: this.name
          })
        });
        const data = await response.json();
        if (data.success) {
          this.error = '';
          const newId = data.id;
          router.push(`/theatre/${newId}`);
        } else {
          this.error = data.message;
          router.push('/theatres');
        }
      } catch (error) {
        this.error = error;
      }
    }
  },

  async mounted() {
    await this.fetchTheatre();
  }
});

export default ModifyExScreens;

