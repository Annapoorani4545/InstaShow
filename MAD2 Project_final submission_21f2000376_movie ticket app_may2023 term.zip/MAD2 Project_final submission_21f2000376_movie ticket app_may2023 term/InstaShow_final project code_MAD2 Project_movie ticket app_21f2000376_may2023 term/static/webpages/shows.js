const Shows = Vue.component("shows", {
  template: `
    <div style="text-align: center; margin-bottom: 20px;">
      <h1>Shows Currently Available:</h1>
      <div style="display: flex; justify-content: space-between; align-items: center;">
        <button style="background-color: #007bff; color: #fff; border: none; padding: 5px 10px; cursor: pointer;" @click="download"><i class="fa fa-download"></i> Download CSV</button>
      </div>
      <div class="row justify-content-center align-items-top" style="margin-top: 20px;">
        <div class="col-lg-3" style="text-align: center">
          <p style="margin: 0;">Search Show by Name</p>
          <form @submit.prevent="me_scr">
            <input type="text" v-model="search" name="search" style="border: 1px solid #ccc; padding: 5px;">
            <button type="submit" style="background-color: #17a2b8; color: #fff; border: none; padding: 5px 10px; cursor: pointer;"><i class="fa fa-search"></i></button>
          </form>
        </div>
        <div class="col-lg-3" style="text-align: center">
          <p style="margin: 0;">Search Show by Rating</p>
          <form @submit.prevent="me_rat">
            <input type="text" v-model="search_rating" name="search_rating" style="border: 1px solid #ccc; padding: 5px;">
            <button type="submit" style="background-color: #17a2b8; color: #fff; border: none; padding: 5px 10px; cursor: pointer;"><i class="fa fa-search"></i></button>
          </form>
        </div>
        <div class="col-lg-3" style="text-align: center">
          <p style="margin: 0;">Search Show by Tags</p>
          <form @submit.prevent="me_gat">
            <select v-model="search_tags" name="search_tags" style="border: 1px solid #ccc; padding: 5px;">
              <option v-for="tag in tags" :value="tag.id">{{ tag.name }}</option>
            </select>
            <button type="submit" style="background-color: #17a2b8; color: #fff; border: none; padding: 5px 10px; cursor: pointer; margin-bottom: 40px;"><i class="fa fa-search"></i></button>
          </form>
        </div>
      </div>
      <label class="error" v-if="error" style="color: red;">{{ error }}</label>
      <h3 v-if="message" style="color: green;">{{ message }}</h3>
      <table style="border-collapse: collapse; width: 100%;" class="table table-bordered table-hover">
        <thead>
          <tr>
            <td style="border: 1px solid #000;">Movie Screening</td>
            <td style="border: 1px solid #000;">Movie Rating</td>
            <td style="border: 1px solid #000;">Ticket Price per Seat</td>
          </tr>
        </thead>
        <tbody>
          <tr v-for="show in shows">
            <td style="border: 1px solid #000;"><router-link :to="'/show/' + show.id">{{ show.name }}</router-link></td>
            <td style="border: 1px solid #000;">{{ show.rating }}</td>
            <td style="border: 1px solid #000;">{{ show.ticket_price }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  `,

  data() {
    return {
      shows: [],
      tags: [],
      search: '',
      search_rating: '',
      search_tags: '',
      error: '',
      message: ''
    }
  },

  methods: {
    async fetchShows() {
      try {
        const response = await fetch('/api/shows', { method: 'GET' });
        const data = await response.json();
        if (data.success) {
          this.shows = data.shows;
          this.message = '';
          this.error = '';
        } else {
          this.message = data.message;
          this.error = '';
        }
      } catch (error) {
        this.error = error;
        this.message = '';
      }
    },

    async fetchTags() {
      try {
        const response = await fetch('/api/tags', { method: 'GET' });
        const data = await response.json();
        if (data.success) {
          this.tags = data.tags;
          this.message = '';
          this.error = '';
        } else {
          this.message = '';
          this.error = '';
        }
      } catch (error) {
        this.error = error;
        this.message = '';
      }
    },

    async me_scr() {
      this.searchShows('/api/me_scr', this.search);
    },

    async me_rat() {
      fetch('/api/me_rat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          search: this.search_rating
        })
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          this.shows = data.shows;
          this.message = '';
          this.error = '';
        } else {
          this.message = data.message;
          this.error = '';
        }
      })
      .catch(error => {
        this.error = error;
        this.message = '';
      });
    },

    async me_gat() {
      this.searchShows('/api/me_gat', this.search_tags);
    },

    async searchShows(url, searchData) {
      try {
        const response = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ search: searchData })
        });
        const data = await response.json();
        if (data.success) {
          this.shows = data.shows;
          this.message = '';
          this.error = '';
        } else {
          this.message = data.message;
          this.error = '';
        }
      } catch (error) {
        this.error = error;
        this.message = '';
      }
    },

    async download() {
      try {
        const response = await fetch(`/api/download_mscr`);
        const blob = await response.blob();
        const filename = 'show_data.csv';
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } catch (error) {
        this.error = error;
      }
    }
  },

  mounted() {
    this.fetchTags();
    this.fetchShows();
  }
})

export default Shows;

