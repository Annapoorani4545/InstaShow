from flask import Flask, render_template, request, jsonify, send_file
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_login import LoginManager, login_user, logout_user, UserMixin, current_user
from flask_caching import Cache
from datetime import datetime, date, time, timedelta
import csv
from sqlalchemy_utils import database_exists, create_database
from docxtpl import DocxTemplate
from celery import Celery

#imports are done for proper functioning of app.
#the above includes a diverse range of imports for building the Flask-based web application.
#It begins with essential Flask imports such as Flask itself, rendering templates, handling HTTP requests, and managing JSON responses. SQLAlchemy is utilized for database operations, while Flask extensions like Bcrypt and LoginManager facilitate user authentication and
#password hashing. Additionally, the code incorporates features like caching through Flask-Caching, date and time handling with datetime and
#related modules, CSV file manipulation, database management with SQLAlchemy-Utils, Word document templating using DocxTemplate, and
#asynchronous task processing through Celery. These imports collectively enable the development of a feature-rich web application with
#capabilities spanning web routing, user management, data storage, caching, document generation, and background task execution.

#creating a flask app for backend of the application
#configuring database connection
#setting flask environment to development mode
#starting the redis-server on local system and updating cache used to redis with timeout of 5400 seconds or 1.5 hours.

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///instashowfinala.db"
app.config['SECRET_KEY'] = 'MYSECABC'
app.config['FLASK_APP'] = 'app.py'
app.config['FLASK_ENV'] = 'development'
app.config['CACHE_TYPE'] = 'redis'
app.config['CACHE_DEFAULT_TIMEOUT'] = 5400

db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
cache = Cache(app)
login_manager = LoginManager(app)

#The above code initializes essential components for the web application:
#Sets up a database interface (SQLAlchemy) for interacting with the database using Python objects.
#Configures password hashing and salting (Bcrypt) for secure user authentication.
#Establishes a caching system (Cache) to improve application performance by storing frequently accessed data in memory.


def make_celery(app):
    celery = Celery(
        "app",
        backend=app.config['result_backend'],
        broker=app.config['CELERY_BROKER_URL'],
        enable_utc = False,
        timezone = "Asia/Calcutta"
    )
    celery.conf.update(app.config)

    class ContextTask(celery.Task):
        def __call__(self, *args, **kwargs):
            with app.app_context():
                return self.run(*args, **kwargs)

    celery.Task = ContextTask
    return celery

app.config.update(
    CELERY_BROKER_URL='redis://localhost:6379',
    result_backend='redis://localhost:6379'
)
celery = make_celery(app)

#The above code defines a function make_celery for configuring a Celery instance within a Flask application.
#It sets up Celery with Flask's configuration values, ensures tasks run within the Flask application context, and returns the configured Celery instance.


#then we start defining the classes or models, so as to utilise the connected database and make the code more organised.

#the first class we define here is user corresponding to table name present in the database with columns id,
#username,email, password and auth which has 2 values 1 or 2 in which 2 indicates admin user and 1 indicates customer.
#this is to differentiate the functionalities for each class of users.

#we also bycrpt hash the password so as to keep data confidential and not be accessed directly by anyone.
#we also verify the same using a function whenever a login is made.

class User(UserMixin, db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    email = db.Column(db.String, unique=True, nullable=False)
    password_hash = db.Column(db.String, nullable=False)
    auth = db.Column(db.Integer, nullable=False, default=1)

    @property
    def password(self):
        raise AttributeError('Password cannot be accessed directly.')

    @password.setter
    def password(self, password):
        self.password_hash = bcrypt.generate_password_hash(password).decode('utf-8')

    def verify_password(self, password):
        return bcrypt.check_password_hash(self.password_hash, password)
    
    def get_id(self):
        return str(self.id)

#next we define the important theatre class with columns id, name, location, capacity, viewers and revenue generated.

class Theatre(db.Model):
    __tablename__ = 'theatre'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String, unique=True, nullable=False)
    location = db.Column(db.String, unique=True, nullable=False)
    seating = db.Column(db.Integer, nullable=False)
    guests = db.Column(db.Integer, nullable=False, default=0)
    income = db.Column(db.Integer, nullable=False, default=0)

#we define class tag having columns id and name. these are movie tags that are seperately defined like shows and theatres and also can be created, edited or removed.

class Tag(db.Model):
    __tablename__ = 'tag'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)


#we define class called book representing 'booking' details and having columns id, user_id, show_id, theatre_id, running_id(foreign key reference from running table, show name,
# theatre name, tickets to be sold, ticket_prices, start and end time of the particular show booking made.)

class Book(db.Model):
    __tablename__ = 'book'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    show_id = db.Column(db.Integer, db.ForeignKey('show.id'), nullable=False)
    theatre_id = db.Column(db.Integer, db.ForeignKey('theatre.id'), nullable=False)
    running_id = db.Column(db.Integer, db.ForeignKey('running.id'), nullable=False)
    show_name = db.Column(db.String, nullable=False)
    theatre_name = db.Column(db.String, nullable=False)
    tickets = db.Column(db.Integer, nullable=False)
    ticket_price = db.Column(db.Integer, nullable=False)
    start_time = db.Column(db.String, nullable=False)
    end_time = db.Column(db.String, nullable=False)


# we define the important class 'show' having show details for each show added, edited or deleted. the details including
#id, name rating, tags, ticket_pricing, viewers and revenue generated.


class Show(db.Model):
    __tablename__ = 'show'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String, unique=True, nullable=False)
    rating = db.Column(db.String(5), nullable=False)
    tags = db.relationship('Tag', secondary='showtags')
    ticket_price = db.Column(db.Integer, nullable=False)
    watchers = db.Column(db.Integer, nullable=False, default=0)
    sreturns = db.Column(db.Integer, nullable=False, default=0)


##then we define class called running so as to store details of shows happening in respective theatres at the moment users login to look for in the app,
#and hence be able to portray it and use it for many other functions.


class Running(db.Model):
    __tablename__ = 'running'
    id = db.Column(db.Integer, primary_key=True)
    show_id = db.Column(db.Integer, db.ForeignKey('show.id'), nullable=False)
    theatre_id = db.Column(db.Integer, db.ForeignKey('theatre.id'), nullable=False)
    show_name = db.Column(db.String, nullable=False)
    theatre_name = db.Column(db.String, nullable=False)
    start_time = db.Column(db.String, nullable=False)
    end_time = db.Column(db.String, nullable=False)
    ticket_price = db.Column(db.Integer, nullable=False)
    rating = db.Column(db.String, nullable=False)


#then we define class 'message' to connect to table message in database, so that it can be updated here
# with correct notifications to the users, especially about cancelled shows and refund. it has columns id, user_id and notifi (message contents)


class Message(db.Model):
    __tablename__ = 'messages'
    id = id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    notifi = db.Column(db.String, nullable=False)
    time = db.Column(db.String, nullable=False)


#finally we define class named Showtags so as interconnect tag id's with show id and hence be displayed as and when called for under shows table or as seperate table.'


class Showtags(db.Model):
    __tablename__ = 'showtags'
    id = db.Column(db.Integer, primary_key=True)
    show_id = db.Column(db.Integer, db.ForeignKey('show.id'), nullable=False)
    tag_id = db.Column(db.Integer, db.ForeignKey('tag.id'), nullable=False)


#Class definitions are now over. now moving to the main part of the code where backend functions defined in python that are called for by javascripts.

#################################################################################################################################################################

#first loading the users
#The below code defines a function load_user used for user authentication in a web application.
# It checks if a valid user ID is provided and retrieves a corresponding user object from a database using an ORM like SQLAlchemy.
# If no valid ID is provided, it returns None.

@login_manager.user_loader
def load_user(id):
    if id is not None:
        return User.query.get(id)
    return None


#next we define / path which is the first redirect to customers when app is run
#The below Flask route decorators define two routes: one for the root path '/' and another for any path specified
# as <path>. When a user visits a URL, it renders the 'mybase.html' template and
# can pass the path as a parameter to the template for dynamic content rendering based on the URL path.

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def Home_Page(path):
    return render_template('mybase.html')

#The below code defines a Flask route '/api/me_gat' that handles POST requests. It takes a 'search' parameter
# from the request JSON, queries a database for a Tag object with that parameter, and then retrieves
# shows associated with that tag. If no shows are found, it returns a failure message; otherwise,
# it returns a JSON response with the found shows.

@celery.task
@app.route('/api/me_gat', methods=['POST'])
def me_gat():
    enn = request.json.get('search')
    cu = Tag.query.get(enn)
    ap = [{'id': z.id, 'name': z.name, 'rating': z.rating, 'ticket_price': z.ticket_price} for z in Show.query.all() if cu in z.tags]
    if not ap:
        return jsonify({'success': False, 'message': 'No shows found! Please Check again.'}), 200
    return jsonify({'success': True, 'shows': ap}), 200


#The below code defines a Flask route /api/adscr that accepts POST requests. It takes a JSON request, extracts a
# 'search' parameter, and then searches for theaters in a database whose 'location' matches the search
# parameter in a case-insensitive manner. If theaters are found, it returns a JSON response with the theaters'
# details; otherwise, it returns an error message indicating that no theaters were found.

@celery.task
@app.route('/api/adscr', methods=['POST'])
def adscr():
    neni = request.json.get('search')
    yess = [{'id': bab.id, 'name': bab.name, 'location': bab.location, 'seating': bab.seating} for bab in Theatre.query.all() if neni.lower() in bab.location.lower()]
    if not yess:
        return jsonify({'success': False, 'message': 'no such theatre found! Please check again.'}), 200
    return jsonify({'success': True, 'theatres': yess}), 200



#The below Python function, har_mas, calculates a future datetime ai set to the first day of the next month
# at midnight. It then checks if the current datetime is greater than ai and adjusts ai accordingly.
# Finally, it schedules a task called monthly to run asynchronously at the calculated ai time using
# the apply_async method, effectively scheduling a monthly task.

def har_mas():
    ai = datetime.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    if datetime.now() > ai:
        ai = ai.replace(month=ai.month + 1)
    else:
        ai = ai.replace(month=datetime.now().month)
    monthly.apply_async(eta=ai)


#The below code defines a Flask route at '/api/logout' that handles POST requests.
# When accessed, it logs out the user, deletes two cached items ('api_My_Bookings' and 'api_messages'),
# and responds with a JSON message indicating success with an HTTP status code 200.

@celery.task
@app.route('/api/logout', methods=['POST'])
def logout():
    logout_user()
    cache.delete('api_My_Bookings')
    cache.delete('api_messages')
    return jsonify({'success': True}), 200

#The below code defines a Flask route '/api/me_rat' that accepts POST requests. It retrieves a 'search' parameter
# from the JSON request, filters shows in a database by their 'rating' attribute, and returns a JSON
# response with the filtered shows if any match is found. If no shows match the criteria, it returns a
# JSON response indicating no shows were found.

@celery.task
@app.route('/api/me_rat', methods=['POST'])
def me_rat():
    rati = request.json.get('search')
    bes = [{'id': d.id, 'name': d.name, 'rating': d.rating, 'ticket_price': d.ticket_price} for d in Show.query.all() if d.rating == rati]
    if not bes:
        return jsonify({'success': False, 'message': 'No shows found! Please check again.'}), 200
    return jsonify({'success': True, 'shows': bes}), 200



#The below Flask route '/api/check_slogin' checks if a user is authenticated. If authenticated, it returns
# the user's ID, username, email, and authentication status in JSON format with a 'True' flag for 'isSLogin.'
# If not authenticated, it returns 'False' for 'isSLogin.' The response status code is set to 200 (OK) in
# both cases.

@celery.task
@app.route('/api/check_slogin')
def customer_data():
    if current_user.is_authenticated:
        sat = {'id': current_user.id, 'username': current_user.username, 'email': current_user.email, 'auth': current_user.auth}
        return jsonify({'isSLogin': True, 'user': sat}), 200
    else:
        return jsonify({'isSLogin': False}), 200

#The below code defines a Celery task called schedule_daily_reminder. It retrieves a list of all users,
# checks if each user does not have a ticket for the day, and if so, sends them a daily reminder.
# Finally, it returns the message "Daily Reminder sent" after processing all users.

@celery.task
def schedule_daily_reminder():
    users = User.query.all()
    for user in users:
        if not has_ticket_today(user.id):
            send_daily_reminder(user.id)

    return "Daily Reminder sent"

#The below Python function, has_ticket_today, checks if a user with a given user_id has booked a ticket
# for today's date by querying a database using SQLAlchemy. It returns True if a booking exists for the
# specified user on the current date, and False otherwise.

def has_ticket_today(user_id):
    today = date.today()
    return db.session.query(Book).filter_by(user_id=user_id).filter(
        db.func.date(Book.start_time) == today
    ).first() is not None



#The below code defines a Flask route '/api/varapora' that responds to HTTP GET requests. It retrieves
# upcoming shows from a database where the start time is greater than the current time, formats the
# data into a JSON response, and returns it. If there are no upcoming shows, it returns a JSON response
# indicating so.

@celery.task
@app.route('/api/varapora', methods=['GET'])
def varapora():
    gyar = datetime.now().strftime("%d-%m-%Y %H:%M")
    por = Running.query.filter(Running.start_time > gyar).all()

    if not por:
        return jsonify({'success': False, 'message': 'No upcoming shows added yet! Please check again'}), 200

    efan = [{'id': dum.id, 'show_name': dum.show_name, 'theatre_name': dum.theatre_name, 'ticket_price': dum.ticket_price,
             'rating': dum.rating, 'start_time': dum.start_time, 'end_time': dum.end_time} for dum in por]

    return jsonify({'success': True, 'data': efan}), 200



#The below Python function sends a daily reminder message to a user with the specified user_id, encouraging
# them to secure event tickets. It creates a message object with the reminder content and timestamp,
# adds it to a database session, and then commits the session. Lastly, it clears a cache key 'api_messages'
# likely to refresh cached message data.

def send_daily_reminder(user_id):
    message = Message(
        user_id=user_id,
        notifi="Today, you haven't secured any tickets. Be sure not to pass up the chance to see some amazing shows!",
        time=datetime.now().strftime("%d-%m-%Y %H:%M")
    )
    db.session.add(message)
    db.session.commit()
    cache.delete('api_messages')


# Usage:
# schedule_daily_reminder()


#The below Python function, everyday(), calculates the next occurrence of a daily reminder to be sent at 9:00 PM.
# If the current time (abhi) is past 9:00 PM, it schedules the reminder for the following day at the same
# time using a task scheduler (schedule_daily_reminder.apply_async).

def everyday():
    abhi = datetime.now()
    focus = abhi.replace(hour=21, minute=0, second=0, microsecond=0)
    if abhi > focus:
        focus += timedelta(days=1)
    schedule_daily_reminder.apply_async(eta=focus)


#The below code defines an API route in a Flask application that retrieves messages for a user with a
# specified 'id'. It first queries the database for messages associated with the user, and if none are found,
# it returns a JSON response indicating no messages. Otherwise, it returns a JSON response containing the
# messages' details. Caching is used to optimize the API's performance by storing responses with the same
# key_prefix for quicker retrieval.

@celery.task
@app.route('/api/messages/<int:id>')
@cache.cached(key_prefix='api_messages')
def messages(id):
    asi = Message.query.filter_by(user_id=id).all()

    if not asi:
        return jsonify({'success': False, 'message': 'No messages as of yet!'}), 200

    n = [{'id': message.id, 'time': message.time, 'notifi': message.notifi} for message in asi]

    return jsonify({'success': True, 'messages': n}), 200



#The below Python function monthly() appears to be a task defined using the Celery library.
# It retrieves information about users' movie bookings made in the previous month, calculates the total amount
# spent, and sends a reminder message to each user about their booking history and encourages them to
# book tickets for the current month. Finally, it returns a message indicating that the monthly reminders
# have been sent.

@celery.task
def monthly():
    a = datetime(datetime.today().year, datetime.today().month - 1, 1)
    z = datetime(datetime.today().year, datetime.today().month, 1) - timedelta(days=1)
    for yes in range(1, len(User.query.all()) + 1):
        res = Book.query.filter(datetime.strptime(Book.start_time, "%Y-%m-%d %H:%M").date()>=a,
                                     datetime.strptime(Book.start_time, "%Y-%m-%d %H:%M").date()<=z,
                                     user_id=yes).all()
        y = len(res)
        am = sum([mt.ticket_price for mt in res])
        noti = Message(
            user_id=yes,
            notifi=f"Dear Cinephile, you have only booked movie tickets {y} times in the last month for a total amount of {am}. So, don't wait! Hurry!, check out the latest movie releases and book your tickets in advance!! Affordable ticket prices exclusively on InstaShow. This month's movie madness awaits you!!",
            time=datetime.now().strftime("%d-%m-%Y %H:%M")
        )
        db.session.add(noti)
        db.session.commit()
        cache.delete('api_messages')
    return 'Monthly reminder sent'


#The below code defines a Flask route that handles the booking of tickets for a show in a theater. It first
# checks if the specified running show, show, and theater exist. Then, it checks if there are enough available
# seats for the requested number of tickets and if the show is not in the past. If all conditions are met,
# it books the tickets, updates relevant data, and returns a success response with status 200. Otherwise,
# it returns an error message with an appropriate HTTP status code (404 or 409).

@celery.task
@app.route('/api/vaangu/<int:user_id>/<int:running_id>', methods=['POST'])
def vaangu(user_id, running_id):
    nazli = Running.query.get(running_id)
    if nazli is None:
        return jsonify({'success': False, 'message': 'No such running show exists! Please check again.'}), 404

    ferit = Show.query.get(nazli.show_id)
    asu = Theatre.query.get(nazli.theatre_id)

    if ferit is None or asu is None:
        return jsonify({'success': False, 'message': 'No such show or theatre exists! Please check again.'}), 404

    sup = int(request.json.get('tickets'))

    if nazli.start_time <= datetime.now().strftime("%d-%m-%Y %H:%M"):
        return jsonify(
            {'success': False, 'message': 'Show is currently running or is in the past! Please check again.'}), 409

    can = 0
    for yi in Book.query.filter_by(theatre_id=asu.id).all():
        if yi.end_time > nazli.start_time:
            can += yi.tickets

    if can + sup > asu.seating:
        return jsonify(
            {'success': False, 'message': 'Sorry, show is running at full capacity! Please check again.'}), 409

    feriha = Book(
        user_id=user_id,
        show_id=ferit.id,
        theatre_id=asu.id,
        running_id=running_id,
        tickets=sup,
        show_name=ferit.name,
        theatre_name=asu.name,
        ticket_price=ferit.ticket_price,
        start_time=nazli.start_time,
        end_time=nazli.end_time
    )

    db.session.add(feriha)
    ferit.watchers += sup
    ferit.sreturns += sup * ferit.ticket_price
    asu.income += sup * ferit.ticket_price
    ferit.ticket_price += ferit.ticket_price * sup * 0.20
    nazli.ticket_price = ferit.ticket_price
    asu.guests += sup

    db.session.commit()
    cache.delete('api_My_Bookings')

    return jsonify({'success': True}), 200



#The below Python code defines a Flask route that handles HTTP DELETE requests to delete a message with a specific
# ID from a database. It checks if the message exists, deletes it, updates the cache, and returns a success
# or failure response with an appropriate status code.

@celery.task
@app.route('/api/messages/<int:id>', methods=['DELETE'])
def delete_message(id):
    hi = Message.query.get(id)
    if not hi:
        return jsonify({'success': False, 'message': "No such messages exist"}), 409
    db.session.delete(hi)
    db.session.commit()
    cache.delete('api_messages')
    return ({'success': True, 'message': "the message is Successfully deleted"}), 200

from sqlalchemy import or_

#The below Flask route (/api/theatres) handles POST requests to add a new theater to a database. It first
# checks if a theater with the same name or location already exists. If so, it returns a 409 (Conflict)
# response with an error message. If not, it adds the new theater to the database, clears a cache, and returns
# a success response with the ID of the newly created theater.

@app.route('/api/theatres', methods=['POST'])
def Add_NewScreen():
    af = request.json.get('name')
    tt = request.json.get('location')
    av = int(request.json.get('seating'))

    if Theatre.query.filter(or_(Theatre.name == af, Theatre.location == tt)).first():
        return jsonify(
            {'success': False, 'message': 'Theatre with that name or location already exists. Please check again'}), 409

    sc = Theatre(name=af, location=tt, seating=av)
    db.session.add(sc)
    db.session.commit()
    cache.delete('api_theatres')

    return jsonify({'success': True, 'id': sc.id}), 200


#def statistics(self):
    # Calculate the number of ordered tickets and the db percentage
#    pbuy_tiets = len(selfapp.user_data)
#    percent_purchased = (pordered_ticks / self.total) * 100

    # Calculate the current income
#    cursogo_incotyhme = sum(usetyhr_info['Price'] for urftser_info in self.user_data.values())

    # Calculate the total income
#    if self.total > 60:
#
#        total2 = (self.rows - half) * self.cols * 8
#        income = 10 * self.total##

    # Create the statistics message
#    stats = (
#        hased Tickets: {percent_purchased:.2f}%\n"
#        f"Current Income: {current_income}\n"
#        f"Total Income: {total_income}"
#    )#

    # Print the statistics
#    print(stats)




#The below code defines a Celery task and a Flask route for an API endpoint '/api/My_Bookings/int:id'.
# It retrieves booking information for a user with the specified 'id', checks if there are any bookings,
# and returns the results as JSON. If there are no bookings, it returns a failure message. It also utilizes
# caching to optimize performance.

@celery.task
@app.route('/api/My_Bookings/<int:id>')
@cache.cached(key_prefix='api_My_Bookings')
def My_Bookings(id):
    good = Book.query.filter_by(user_id=id).all()
    if not good:
        return jsonify({'success': False, 'message': 'no bookings made yet! Please check again'}), 200
    rii = [{'id': htt.id, 'show_name': htt.show_name, 'running_id': htt.running_id, 'theatre_name': htt.theatre_name,
             'tickets': htt.tickets, 'start_time': htt.start_time, 'end_time': htt.end_time} for htt in good]
    return jsonify({'success': True, 'bookings': rii}), 200

from sqlalchemy import func


#The below Python code defines a Flask route /api/download_screensinfo that, when accessed, generates a
# CSV file containing data from a database table (Theatre) and sends it as a downloadable attachment
# in the HTTP response. The CSV file includes columns for 'Name,' 'Location,' and 'Seating,' and it is
# named 'theatre_data.csv' for download.

@celery.task
@app.route('/api/download_screensinfo')
def download_screensinfo():
    mou = ['Name', 'Location', 'Seating']
    lop = [[k.name, k.location, k.seating] for k in Theatre.query.all()]

    # Create a CSV string in memory
    csv_data = StringIO()
    csvwriter = csv.writer(csv_data)
    csvwriter.writerow(mou)
    csvwriter.writerows(lop)

    # Return the CSV data as a response
    response = Response(csv_data.getvalue(), content_type='text/csv')
    response.headers['Content-Disposition'] = 'attachment; filename=screen_data.csv'
    return response, 200



#The below code defines a Flask route at '/api/scr_now' that queries a database for currently running movie
# screenings within a specific time frame (start_time and end_time). If there are running screenings,
# it creates a JSON response with details of the screenings; otherwise, it returns a message indicating
# no screenings are currently running.

@celery.task
@app.route('/api/scr_now')
def scr_now():
    noww = datetime.now().strftime("%d-%m-%Y %H:%M")
    nowb = Running.query.filter(Running.start_time <= noww, Running.end_time >= noww).all()

    if not nowb:
        response = {'success': False, 'message': 'No movie screenings running at the moment! Please check again.'}
        return jsonify(response), 200

    adinf = [{
        'id': u.id,
        'show_name': u.show_name,
        'theatre_name': u.theatre_name,
        'ticket_price': u.ticket_price,
        'rating': u.rating,
        'start_time': u.start_time,
        'end_time': u.end_time
    } for u in nowb]

    response = {'success': True, 'data': adinf}
    return jsonify(response), 200



#The below Flask route, when accessed at '/api/user', checks if the current user is authenticated.
# If authenticated, it returns the user's data (ID, username, email, auth) in JSON format with a 200
# status code. If not authenticated, it returns an error message with a 401 status code.

@app.route('/api/user')
def get_user_data():
    if current_user.is_authenticated:
        user_data = {
            'id': current_user.id,
            'username': current_user.username,
            'email': current_user.email,
            'auth': current_user.auth
        }
        return jsonify({'user': user_data}), 200
    else:
        return jsonify({'error': 'User not authenticated'}), 401

#    def showthe_boo_ticse_info(self):
#        for k, v in self.userytu_data.items():
#            prnt("Seat No. : ", k, end="--> ")
#            print(er_Info : ", v)##

#    def exit(self):
#        pass



#The below code defines a route in a web application that handles the deletion of a booking specified by its ID.
# It first checks if the booking exists; if not, it returns an error message with status code 409.
# Then, it checks for related information like the show, theatre, and running details and returns a 404
# error if any of them is not found. Next, it checks if the show is in the past or currently running,
# returning a 409 error in such cases. Finally, it updates various data related to the booking, deletes
# the booking from the database, and returns a success message with a 200 status code.

@celery.task
@app.route('/api/rmmb/<int:id>', methods=['DELETE'])
def rmmb(id):
    oz = Book.query.get(id)
    if not oz:
        return jsonify({'success': False, 'message': 'Booking not found! Please check again.'}), 409

    ge = Show.query.get(oz.show_id)
    rel = Theatre.query.get(oz.theatre_id)
    nada = Running.query.get(oz.running_id)

    if not ge or not rel or not nada:
        return jsonify({'success': False, 'message': 'Screen, show not found! Please check again'}), 404

    alli = datetime.now()
    if nada.start_time <= alli.strftime("%d-%m-%Y %H:%M"):
        return jsonify(
            {'success': False, 'message': 'Show is in the past or running at present! Please check again.'}), 409

    ge.watchers -= oz.tickets
    ge.ticket_price = int(ge.ticket_price / (1 + (0.20 * oz.tickets)))
    nada.ticket_price = ge.ticket_price
    ge.sreturns -= oz.tickets * oz.ticket_price
    rel.income -= oz.tickets * oz.ticket_price
    rel.guests -= oz.tickets
    db.session.delete(oz)
    db.session.commit()
    cache.delete('api_My_Bookings')
    return jsonify({'success': True}), 200



#The below Python code defines a Flask route '/api/theatres' that queries a database for theatre information.
# If there are theatres in the database, it returns a JSON response with their details; otherwise,
# it returns a message indicating that no screens have been added yet. The @celery.task decorator suggests
# that it might be integrated with a Celery task queue for asynchronous processing, and @cache.cached indicates
# the use of caching to improve response times for repeated requests.

@celery.task
@app.route('/api/theatres')
@cache.cached(key_prefix='api_theatres')
def theatres():
    scr = Theatre.query.all()

    if not scr:
        return jsonify({'success': False, 'message': 'No screens added yet!'}), 200

    sca = [{'id': cc.id, 'name': cc.name, 'location': cc.location, 'seating': cc.seating} for cc in scr]

    return jsonify({'success': True, 'theatres': sca}), 200

import csv
from flask import Flask, Response
from io import StringIO



#The below Python Flask route (/api/shows) handles a POST request to add a new show to a database.
# It checks if a show with the provided name already exists, and if not, it creates a new show with the given
# attributes (name, rating, ticket price, and tags) and returns a success response with the show's ID.
# If the show name already exists, it returns an error response with a message and a status code
# 409 (Conflict). Additionally, it clears a cache for 'api_shows' after adding the new show to the database.


@app.route('/api/shows', methods=['POST'])
def Add_NewShow():
    sn = request.json.get('name')
    sr = request.json.get('rating')
    pm = int(request.json.get('ticket_price'))
    the = request.json.get('tags')

    if Show.query.filter_by(name=sn).first():
        return jsonify({'success': False, 'message': 'the movie name already exists. Please check again'}), 409
    
    nad = Show(name=sn, rating=sr, ticket_price=pm)
    nad.tags = Tag.query.filter(Tag.id.in_(the)).all()
    db.session.add(nad)
    db.session.commit()
    cache.delete('api_shows')
    return jsonify({'success': True, 'id': nad.id}), 200


#The below code defines a Flask route '/api/shows' that retrieves a list of movie shows from a database
# using SQLAlchemy and returns them as JSON. If there are no shows in the database, it returns a JSON response
# indicating the absence of shows. Caching is used to improve performance by storing the results of
# this endpoint with a key prefix 'api_shows'.

@celery.task
@app.route('/api/shows')
@cache.cached(key_prefix='api_shows')
def shows():
    ef = Show.query.all()
    if not ef:
        return jsonify({'success': False, 'message': 'No Movie shows have been added yet!'}), 200
    resu = [{'id': es.id, 'name': es.name, 'rating': es.rating, 'ticket_price': es.ticket_price} for es in ef]
    return jsonify({'success': True, 'shows': resu}), 200

from flask import Flask, make_response
import csv

#The below Flask route function, decorated as a Celery task, generates a CSV file containing data from a
# database query of "Show" records. It then constructs a response with this CSV data, setting the content
# type to CSV, and prompts the user's browser to download it as "show_data.csv".

@celery.task
@app.route('/api/download_mscr')
def download_mscr():
    ht = ['Name', 'Rating', 'Ticket Price']
    cn = [[r.name, r.rating, r.ticket_price] for r in Show.query.all()]
    csv_data = [ht] + cn

    response = make_response('\n'.join([','.join(row) for row in csv_data]), 200)
    response.headers['Content-Disposition'] = 'attachment; filename=show_data.csv'
    response.mimetype = 'text/csv'

    return response


#The below code defines a Flask route '/api/find_screen' that handles a POST request. It searches for theaters
# in a database based on a search term provided in the request JSON, and if found, it returns a JSON
# response with theater details. If no theaters are found, it returns a JSON response indicating failure
# with a corresponding message.

@celery.task
@app.route('/api/find_screen', methods=['POST'])
def find_screen():
    indd = request.json.get('search')
    pex = Theatre.query.filter(func.lower(Theatre.name).contains(indd.lower())).all()

    if not pex:
        return jsonify({'success': False, 'message': 'no such theatres found! Please check again.'}), 200

    res_scr = [{'id': op.id, 'name': op.name, 'location': op.location, 'seating': op.seating} for
               op in pex]

    return jsonify({'success': True, 'theatres': res_scr}), 200




#The below code defines a route in a Flask web application that handles POST requests to '/api/tags'.
# It checks if a tag with the given name already exists in the database. If it exists, it returns a 409
# status code with a message indicating the tag already exists. If not, it adds the new tag to the database,
# clears a cache, and returns a 200 status code with a success message.

@app.route('/api/tags', methods=['POST'])
def Add_NewTags():
    hit = request.json.get('name')
    
    if Tag.query.filter_by(name=hit).first():
        return jsonify({'success': False, 'message': 'Tag name already exists. Please check again.'}), 409
    
    gat = Tag(name=hit)
    db.session.add(gat)
    db.session.commit()
    cache.delete('api_tags')
    return jsonify({'success': True, 'message': 'New Tag successfully added.'}), 200


#The below code defines a Flask route '/api/tags' that retrieves a list of tags from a database using SQLAlchemy
# and returns them as JSON. If no tags exist, it returns a message indicating that no tags
# have been created yet. It also uses caching to improve performance when fetching tags.

@app.route('/api/tags')
@cache.cached(key_prefix='api_tags')
def tags():
    eat = Tag.query.all()
    if not eat:
        return jsonify({'success': False, 'message': 'No tags created yet!'}), 200
    tinf = [{'id': p.id, 'name': p.name} for p in eat]
    return jsonify({'success': True, 'tags': tinf}), 200


#The below Flask route function, when accessed via a POST request, adds a new movie screening to a database.
# It first validates the input data, checks if the specified screening exists, ensures the screening date
# and time are not in the past, and then creates a new screening entry in the database. If successful, it
# returns a JSON response indicating success along with the screening's ID.

@app.route('/api/Add_MovieScreening/<int:id>', methods=['POST'])
def Add_MovieScreening(id):
    ams = Show.query.get(id)

    if not ams:
        return jsonify({'success': False, 'message': 'No such screening exists! Please Check again'}), 404

    try:
        tid = request.json['theatre_id']
        din = datetime.strptime(request.json['date'], "%Y-%m-%d").date()
        ru = datetime.strptime(request.json['start_time'], "%H:%M").time()
        kt = datetime.strptime(request.json['end_time'], "%H:%M").time()
    except ValueError:
        return jsonify({'success': False, 'message': 'You may have entered Invalid date or time format, Please check again'}), 400

    current_datetime = datetime.now()
    input_datetime = datetime.combine(din, ru)

    if input_datetime < current_datetime:
        flash('The screening date and time cannot be in the past', 'error')
        return jsonify({'success': False, 'message': 'The screening date and time cannot be in the past'}), 400

    firu = datetime.combine(din, ru).strftime("%d-%m-%Y %H:%M")
    fikt = datetime.combine(din, kt).strftime("%d-%m-%Y %H:%M")

    screen = Theatre.query.get(tid)

    if not screen:
        return jsonify({'success': False, 'message': 'Sorry! Theatre not found, Please check again.'}), 404

    pling = Running(
        show_id=id,
        theatre_id=tid,
        show_name=ams.name,
        theatre_name=screen.name,
        start_time=firu,
        end_time=fikt,
        ticket_price=ams.ticket_price,
        rating=ams.rating
    )

    db.session.add(pling)
    db.session.commit()

    return jsonify({'success': True, 'id': id}), 200


#def dcc():
#    res = messx.askquon(
#        "Dete Acco", "Do yto deletur acc?"
#    )
#    if res == "yes":
#        dafghtaBase = mysql.connector.connect(
#            hostsdf=dbsfs_hs, user=dbfgh_us, passwd=dbdfd_pw, database=dbxsdc_db
#        )
#        mycursor = dataBcursor()
#        s = "DELETE FROM acc WHEme = %s and pass = %s"
#        v = (usme, pasrd)
#        mycursor.execute(s, v)
#        date.coit()
#        dataB.close()
#        print("Accoted!!")
#    eles == "no":
#        meebox.shfo("Return", "deletng acc")##

#def detyops():
#    root.dcinepil()


#The below Python code defines a Flask route that responds to GET requests at '/api/running/int:id'. It retrieves
# information about a running show with the specified 'id' from a database using SQLAlchemy, and if found,
# returns a JSON response indicating success along with the show details; otherwise, it returns a 404 error
# with a failure message. It appears to be part of a web application for displaying information about running
# shows in a theater.

@celery.task
@app.route('/api/running/<int:id>')
def running(id):
    hv = Running.query.get(id)
    if not hv:
        return jsonify({'success': False, 'message': 'the show is not currently running'}), 404
    ih = {'id': hv.id, 'show_id': hv.show_id, 'theatre_id': hv.theatre_id, 'show_name': hv.show_name,
            'theatre_name': hv.theatre_name, 'start_time': hv.start_time, 'end_time': hv.end_time,
            'ticket_price': hv.ticket_price, 'rating': hv.rating}
    return jsonify({'success': True, 'running': ih}), 200



#The below Python code defines a Flask route that handles HTTP DELETE requests to '/api/running/int:id'.
# It performs several checks and operations related to a running show, its associated theater, and booked
# tickets. If conditions are met, it responds with appropriate JSON messages indicating the success or
# failure of the request.

@app.route('/api/running/<int:id>', methods=['DELETE'])
def r_sc(id):
    cr = Running.query.get(id)
    csx = Show.query.get(cr.show_id)
    ssb = Theatre.query.get(cr.theatre_id)

    def show_not_found_response():
        return jsonify({'success': False, 'message': 'No such shows currently running'}), 404

    def theatre_not_found_response():
        return jsonify({'success': False, 'message': 'The show is currently not running in any Theatre'}), 404

    def show_already_running_response():
        return jsonify({'success': False, 'message': 'Show is currently running'}), 409

    if not csx:
        return show_not_found_response()

    if not ssb:
        return theatre_not_found_response()

    if cr.start_time <= datetime.now().strftime("%d-%m-%Y %H:%M"):
        return show_already_running_response()

    for myres in Book.query.filter_by(running_id=cr.id).all():
        ssb.guests -= myres.tickets
        csx.watchers -= myres.tickets
        ssb.income -= myres.tickets * myres.ticket_price
        csx.sreturns -= myres.tickets * myres.ticket_price

        urc = Message(
            user_id=myres.user_id,
            notifi=f"We are extremely sorry to inform you that, the movie you had booked tickets for - {myres.show_name} - has been cancelled in short notice. the reservation amount will be soon refunded to your account, with 2% interest due to our negligence. Please do continue to browse for other movie screenings to make advanced bookings.",
            time=datetime.now().strftime("%d-%m-%Y %H:%M")
        )

        db.session.add(urc)
        cache.delete('api_messages')
        db.session.delete(myres)

    db.session.delete(cr)
    db.session.commit()
    cache.delete('api_My_Bookings')
    return jsonify({'success': True}), 200


#The below code defines a Flask route /api/signup that handles user sign-up requests via POST method.
# It checks if the provided username and email already exist in the database. If not, it creates a new user,
# logs them in, and returns a success message with user data. If the username or email already exists,
# it returns an error message with a 409 status code, indicating a conflict.

@celery.task
@app.route('/api/signup', methods=['POST'])
def signup():
    # Extract user input from the request
    into = request.json
    cus = into.get('username')
    req = into.get('email')
    has = into.get('password')

    # Check if the username already exists in the database
    th = User.query.filter_by(username=cus).first()
    if th:
        return jsonify({'success': False, 'message': 'Username already exists, Please check again'}), 409

    # Check if the email already exists in the database
    te = User.query.filter_by(email=req).first()
    if te:
        return jsonify({'success': False, 'message': 'Email already exists, Please check again'}), 409

    # Create a new User instance and add it to the database
    au = User(username=cus, email=req)
    au.password = has
    db.session.add(au)
    db.session.commit()

    # Clear cached user data (if any)
    cache.delete('api_users')

    # Log in the newly registered user
    login_user(au, remember=False)

    # Prepare user data for response
    ncus = {'id': au.id, 'username': au.username, 'email': au.email, 'auth': au.auth}

    # Return a success message with user data
    return jsonify({'success': True, 'user': ncus, 'message': 'Account was successfully created!'}), 200


#The below code defines an API endpoint '/api/users' using Flask and Celery. It retrieves the count of users
# from a database table called 'User' and caches the result. It then returns the user count as JSON with a
# HTTP status code 200.

@celery.task
@app.route('/api/users')
@cache.cached(key_prefix='api_users')
def users():
    user_count = len([user for user in User.query.all()])
    return jsonify({'number': user_count}), 200


#The below code defines a Flask route at '/api/me_scr' that handles POST requests. It takes a JSON request with
# a 'search' parameter, queries a database for shows whose names contain the search term in a
# case-insensitive manner, and returns a JSON response. If no matching shows are found, it returns a
# failure message; otherwise, it returns a success message along with the matching shows.

@celery.task
@app.route('/api/me_scr', methods=['POST'])
def me_scr():
    ppy = request.json.get('search')
    ply = [{'id': xc.id, 'name': xc.name, 'rating': xc.rating, 'ticket_price': xc.ticket_price} for xc in Show.query.all() if ppy.lower() in xc.name.lower()]
    if not ply:
        return jsonify({'success': False, 'message': 'Sorry! No such shows found! Please check again'}), 200
    return jsonify({'success': True, 'shows': ply}), 200


#The below code defines a Flask route that handles requests to retrieve information about a theater
# based on its ID. It first checks if the theater exists in the database and returns a 404 error
# if it doesn't. Then, it fetches details about the theater and its running shows and constructs a
# JSON response with the information. Finally, it returns the response with a 200 status code.

@celery.task
@app.route('/api/theatre/<int:id>')
def theatre(id):
    absc = Theatre.query.get(id)

    if not absc:
        return jsonify({'success': False, 'message': 'Theatre like that does not exist'}), 404

    abchal = Running.query.filter_by(theatre_id=id).all()

    response = {
        'success': True,
        'theatre': {
            'id': id,
            'name': absc.name,
            'location': absc.location,
            'seating': absc.seating,
            'guests': absc.guests,
            'income': absc.income,
            'shows': [{'id': run.id, 'name': run.show_name, 'start_time': run.start_time, 'end_time': run.end_time} for
                      run in abchal]
        }
    }

    return jsonify(response), 200

from flask import send_file


#The below Flask route /api/show/<int:id> handles a PUT request to modify a show's details in a database.
# It first checks if the show exists, if it's currently ongoing, and if JSON data is provided in the request.
# Then, it updates the show's attributes, tags, and related records (Running and Book) and commits the changes
# to the database. Finally, it clears relevant cache keys and returns a success message with the show's ID or
# an error message with an appropriate status code.

@app.route('/api/show/<int:id>', methods=['PUT'])
def Modify_ExShow(id):
    hy = Show.query.get(id)

    if not hy:
        return jsonify({'success': False, 'message': 'Such a Show does not exist'}), 404

    nn = datetime.now().strftime("%d-%m-%Y %H:%M")

    # Check if the show is currently ongoing
    if any(v.start_time <= nn for v in Running.query.filter_by(show_id=id).all()):
        return jsonify({'success': False, 'message': 'The show is currently ongoing'}), 409

    # Get JSON data from the request
    data = request.json

    if not data:
        return jsonify({'success': False, 'message': 'No data provided in the request'}), 400

    # Update show attributes
    hy.name = data.get('name', hy.name)
    hy.rating = data.get('rating', hy.rating)

    # Update show tags
    tag_ids = data.get('tags', [])
    hy.tags = Tag.query.filter(Tag.id.in_(tag_ids)).all()

    # Update related Running and Book records
    for v in Running.query.filter_by(show_id=id).all():
        v.show_name = hy.name
        v.rating = hy.rating

    for xs in Book.query.filter_by(show_id=id).all():
        xs.show_name = hy.name

    # Commit changes to the database
    db.session.commit()

    # Clear cache for relevant keys
    cache.delete('api_shows')
    cache.delete('api_My_Bookings')

    return jsonify({'success': True, 'id': hy.id}), 200


from flask import request, jsonify


#The below Python code defines an endpoint for downloading a Microsoft Word document (.docx) file using Flask and
# Celery. It first checks if a theater with the given id exists, and if not, it returns a 404 error.
# Then, it generates a dynamic Word document based on theater details and running shows, saves it,
# and sends the file for download.

@celery.task
@app.route('/api/download_ttd/<int:id>')
def download_ttd(id):
    hosc = Theatre.query.get(id)

    if not hosc:
        return jsonify({'success': False, 'message': 'no such Theatre exists. Please check again'}), 404

    hora = Running.query.filter_by(theatre_id=id).all()

    docx_filename = f'static/dettdown/screen_{id}.docx'
    cm = {
        'name': hosc.name,
        'location': hosc.location,
        'seating': hosc.seating,
        'guests': hosc.guests,
        'income': hosc.income,
        'running_shows': ', '.join([running.show_name for running in hora])
    }

    bel = DocxTemplate('static/dettdown/scrtemplate.docx')
    bel.render(cm)
    bel.save(docx_filename)

    return send_file(docx_filename), 200


@app.route('/api/theatre/<int:id>', methods=['PUT'])
def Modify_ExScreens(id):
    escr = Theatre.query.get(id)
    if not escr:
        return jsonify({'success': False, 'message': 'no such Theatre exists'}), 404
    ally = request.json.get('name')
    escr.name = ally
    for idi in Running.query.filter_by(theatre_id=id).all():
        idi.theatre_name = ally
    for cc in Book.query.filter_by(theatre_id=id).all():
        cc.theatre_name = ally
    db.session.commit()
    cache.delete('api_theatres')
    cache.delete('api_My_Bookings')
    return jsonify({'success': True, 'id': escr.id}), 200

from datetime import datetime
from sqlalchemy.orm.exc import NoResultFound

#The below code defines a Flask API route that handles a PUT request to modify a theater's name based on its ID.
# It first checks if the theater exists, updates its name, and then updates related records in the database.
# Finally, it clears two cache keys and returns a success response with the modified theater's ID.

@app.route('/api/theatre/<int:id>', methods=['DELETE'])
def rmo(id):
    abby = Theatre.query.get(id)
    if not abby:
        return jsonify({'success': False, 'message': 'the Theatre you are looking for does not exist'}), 404
    pok = datetime.now().strftime("%d-%m-%Y %H:%M")
    for icc in Running.query.filter_by(theatre_id=id).all():
        if icc.start_time <= pok:
            return jsonify({'success': False, 'message': 'show is currently ongoing in this theatre, Please try later.'}), 409
    for mal in Book.query.filter_by(theatre_id=id).all():
        ps = Show.query.get(mal.show_id)
        ps.watchers -= mal.tickets
        ps.sreturns -= mal.tickets * mal.ticket_price
        message = Message(
            user_id=mal.user_id,
            notifi=f"We are extremely sorry to inform you that {mal.theatre_name} theatre in which you had booked tickets for the show - {mal.show_name} - has been removed. shortly, you will receive the refunded anount in your bank account",
            time= datetime.now().strftime("%Y-%m-%d %H:%M")
        )
        db.session.add(message)
        cache.delete('api_messages')
        db.session.delete(mal)
    for llp in Running.query.filter_by(theatre_id=id).all():
        db.session.delete(llp)
    db.session.delete(abby)
    db.session.commit()
    cache.delete('api_theatres')
    cache.delete('api_My_Bookings')
    return jsonify({'success': True}), 200


#The below code defines a Flask route at "/api/download_pli/int:id" that takes an integer "id" as a parameter.
# It queries a database to retrieve information about a show and its related data, then uses this data to
# generate a Word document using a template and sends it as a downloadable file. If there are any errors
# during this process, it returns an appropriate error response.

@celery.task
@app.route('/api/download_pli/<int:id>', methods=['GET'])
def download_pli(id):
    try:
        sg = db.session.query(Running).filter_by(show_id=id).all()
        sng = db.session.query(Show).get(id)

        if not sng:
            return jsonify({'error': 'Show not found'}), 404

        template = DocxTemplate('static/runcur/curtemp.docx')
        mg = {
            'name': sng.name,
            'rating': sng.rating,
            'ticket_price': sng.ticket_price,
            'watchers': sng.watchers,
            'sreturns': sng.sreturns,
            'theatres': ', '.join([j.theatre_name for j in sg]),
            'tags': ', '.join([ga.name for ga in sng.tags])
        }

        template.render(mg)
        template.save(f'static/runcur/interest_{id}.docx')

        return send_file(f'static/runcur/interest_{id}.docx')
    except Exception as e:
        return jsonify({'error': str(e)}), 500


from flask import jsonify, request, abort, make_response
from datetime import datetime


#The below Flask route, triggered by a DELETE request to '/api/tag/int:id', deletes a Tag object with the
# specified ID if it exists. If the tag doesn't exist, it returns a 404 error. It also removes the tag
# from associated Show objects, updates the database, clears a cache entry ('api_tags'), and responds
# with a success message if the deletion is successful.

@app.route('/api/tag/<int:id>', methods=['DELETE'])
def togl(id):
    lg = Tag.query.get(id)
    if not lg:
        return jsonify({'success': False, 'message': 'No such tag!'}), 404

    shows = Show.query.filter(Show.tags.contains(lg)).all()
    for show in shows:
        show.tags.remove(lg)

    db.session.delete(lg)
    db.session.commit()
    cache.delete('api_tags')
    return jsonify({'success': True}), 200


from flask import jsonify, request, abort
from datetime import datetime
from flask import flash



#The below code defines a Flask route that retrieves information about a show with a specified ID. It checks if
# the show exists in the database, and if so, it constructs a JSON response containing details about the show,
# its associated theaters, and some other attributes. If the show doesn't exist, it returns a 404 error with a JSON message indicating that the show doesn't exist.

@celery.task
@app.route('/api/show/<int:id>')
def show(id):
    jk = Show.query.get(id)

    if not jk:
        return jsonify({'success': False, 'message': 'the Show does not exist'}), 404

    plsc = []
    for sw in Running.query.filter_by(show_id=id).all():
        plsc.append({
            'id': sw.id,
            'name': sw.theatre_name,
            'start_time': sw.start_time,
            'end_time': sw.end_time
        })

    li = [{'id': qq.id, 'name': qq.name} for qq in jk.tags]

    zz = {
        'id': jk.id,
        'name': jk.name,
        'rating': jk.rating,
        'ticket_price': jk.ticket_price,
        'tags': li,
        'theatres': plsc,
        'watchers': jk.watchers,
        'sreturns': jk.sreturns
    }

    return jsonify({'success': True, 'show': zz}), 200


from flask import Flask, request, jsonify, send_file
from docx import Document
from docxtpl import DocxTemplate


#The below Flask route handles GET requests to '/api/tag/int:id'. It queries a Tag object by its 'id',
# and if found, it returns a JSON response with the tag's information. If not found, it returns a JSON
# response with a 'not found' message and a 404 status code.

from flask import Flask, jsonify, make_response
@app.route('/api/tag/<int:id>')
def tag(id):
    ofc = Tag.query.get(id)
    tam = {'success': False, 'message': 'no tags added yet!'} if not ofc else {'success': True, 'tag': {'id': ofc.id, 'name': ofc.name}}
    status_code = 404 if not ofc else 200
    return make_response(jsonify(tam), status_code)



#The below Python function handles the cancellation of a show with a specified 'id'. It first checks if the show
# exists and if it's current or past, returning appropriate error responses if necessary. Then, it processes
# and cancels bookings associated with the show, deducting income and guest counts from the relevant theatre,
# notifying users, and deleting bookings and associated running instances. Finally, it deletes the show from
# the database, clears relevant cache keys, and returns a success response if all operations are successful.

@app.route('/api/show/<int:id>', methods=['DELETE'])
def cl_sc(id):
    er = Show.query.get(id)
    if not er:
        return jsonify({'success': False, 'message': 'such a Show does not exist'}), 404
    current_time = datetime.now().strftime("%d-%m-%Y %H:%M")
    for ax in Running.query.filter_by(show_id=id).all():
        if ax.start_time <= current_time:
            return jsonify({'success': False, 'message': 'current or past show'}), 409
    for iu in Book.query.filter_by(show_id=id).all():
        tini = Theatre.query.get(iu.theatre_id)
        tini.income -= iu.tickets * iu.ticket_price
        tini.guests -= iu.tickets
        nec = Message(
            user_id=iu.user_id,
            notifi=f"We are extremely sorry to inform you that the show you had booked tickets for - {iu.show_name} - has been canceled. refund amount will be shortly credited to your account.",
            time= datetime.now().strftime("%d-%m-%Y %H:%M")
        )
        db.session.add(nec)
        cache.delete('api_messages')
        db.session.delete(iu)
    for bud in Running.query.filter_by(show_id=id).all():
        db.session.delete(bud)
    db.session.delete(er)
    db.session.commit()
    cache.delete('api_shows')
    cache.delete('api_My_Bookings')
    return jsonify({'success': True}), 200


#The below code defines a Flask route for user login via a POST request.
# It checks the provided username and password, verifies them against a User model, and returns
# a success message with user information if the login is successful; otherwise, it returns an error message
# with a 401 status code indicating unauthorized access. Additionally, it supports remembering
# the user's session based on the 'remember' parameter in the request.

@celery.task
@app.route('/api/login', methods=['POST'])
def login():
    cla = request.json.get('username')
    atb = request.json.get('password')
    sr = request.json.get('remember')

    ex_ent = User.query.filter_by(username=cla).first()

    if ex_ent is None or not ex_ent.verify_password(atb):
        return jsonify({'success': False, 'message': 'You may have entered Invalid username or password! Please check again.'}), 401

    if sr:
        login_user(ex_ent, remember=True)
    else:
        login_user(ex_ent, remember=False)

    fin = {'id': ex_ent.id, 'username': ex_ent.username, 'email': ex_ent.email,
                 'auth': ex_ent.auth}
    return jsonify({'success': True, 'user': fin, 'message': 'successful login!'}), 200


#The below Flask route, triggered by a PUT request to '/api/tag/int:id', modifies an existing tag's name
# identified by the provided 'id'. It first checks if the tag exists; if not, it returns a 404 error.
# Then, it updates the tag's name with the new value from the request JSON, saves it to the database,
# clears a cache for 'api_tags', and responds with a success message and a 200 status code.

@app.route('/api/tag/<int:id>', methods=['PUT'])
def Modify_ExTags(id):
    o = Tag.query.get(id)
    if not o:
        return jsonify({'success': False, 'message': 'no such tags found!'}), 404
    eve = request.json.get('name')
    
    o.name = eve
    db.session.commit()
    cache.delete('api_tags')
    return jsonify({'success': True}), 200


from flask import jsonify, abort


#The below code checks if the Python script is being run as the main program. If it is, it creates a database
# if it doesn't exist and initializes some data. Then, it calls the functions everyday() and har_mas(),
# and finally starts a local web server on port 8000 with debugging enabled using the Flask app defined
# in app.

if __name__ == "__main__":
    with app.app_context():
        if not database_exists(app.config["SQLALCHEMY_DATABASE_URI"]):
            create_database(app.config["SQLALCHEMY_DATABASE_URI"])
            db.create_all()

            #admin = User(username='Annapoorani', email='roughusepoori@gmail.com', auth=2)
            #admin.password = 'Anna@123'
            #db.session.add(admin)
            #db.session.commit()
        everyday()
        har_mas()
    app.run(port=8000, debug=True)

#to login as admin, use username = 'allo1'  and password = 'ABCabc123!' , the email is 'allo801@gmail.com'